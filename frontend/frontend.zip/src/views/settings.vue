<template>
  <div class="settings">
    <div class="container-fluid">
      <div class="container">
        <h1>Settings</h1>
        <div class="row mt-4">
          
        </div>
      </div>

    </div>
  </div>
</template>

<script>
  export default {
    name: 'settings',
    components: {},

    data() {
      return {

      }
    },

    async created() {
      
    },

  };

</script>

<style scoped>
  

</style>
